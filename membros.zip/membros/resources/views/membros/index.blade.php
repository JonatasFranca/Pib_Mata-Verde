@extends('app')


@section('content')







    <div class="container">
        <div class="row main">
            <div class="main-login main-center">
                <div>
                    <figure align="right">
                        <img src="{{ asset('/css/imagem/pib- Mata Verde.jpg') }}" alt="pib"  height="140" width="200">
                    </figure>
                </div>
                {{ Session::get('message') }}

                    <a href="{{ route('membros.create') }}" class="btn-sm btn-primary" ><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Novo Membro</a>

                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>Membros</th>

                            <th>Total de Membros = {{$total}}  <a href="{{ route('membros.grafico') }}" ><span class="glyphicon glyphicon-stats" aria-hidden="true"></span></a></th>
                        </tr>
                        </thead>
                        <tbody>


                        @foreach($todosmembros as $membros)

                                <tr>
                                    <td><a href="{{ route('membros.show',['id'=>$membros->id]) }}" >{{ $membros->nome }}</a></td>


                                    <td>
                                        <a href="membros/{{ $membros->id }}/edit" class="btn-sm btn-default" >Editar</a>
                                        <a href="{{ route('membros.pdf',['id'=>$membros->id]) }}" class="btn-sm btn-success">Imprimir Ficha</a>



                                    </td>
                                </tr>


                        @endforeach

                        </tbody>
                    </table>
                </div>
        </div>
    </div>

@endsection