@extends('app')


@section('content')

<div class="container">
    <div class="row main">
        <div class="main-login main-center">
            <div>
                <figure align="right">
                    <img src="{{ asset('/css/imagem/pib- Mata Verde.jpg') }}" alt="pib"  height="140" width="200">
                </figure>
            </div>
            <h2>Cadastro de Membros </h2>

            <form class="" method="post" action="store">

                <div class="form-group">
                    <label for="name" class="cols-sm-2 control-label">Nome</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                            <input type="text" name="nome" value="" placeholder="Nome" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="email" class="cols-sm-2 control-label">Endereço</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home fa" aria-hidden="true"></i></span>
                            <input type="text" name="rua" value="" placeholder="Rua"class="form-control">
                        </div>
                    </div>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home fa" aria-hidden="true"></i></span>
                            <input type="text" name="bairro" value="" placeholder="Bairro" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Estado Civil</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-heart fa" aria-hidden="true"></i></span>
                            <select  class="form-control" name="estado_civil">
                                <option value="solteiro">Solteiro</option>
                                <option value="casado">Casado</option>
                                <option value="divorciado">Divorciado</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Data Nascimento</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-calendar fa" aria-hidden="true"></i></span>
                            <input type="date" name="data_nascimento"  placeholder="data_nascimento" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Data Casamento</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-calendar fa" aria-hidden="true"></i></span>
                            <input type="date" name="data_casamento"  placeholder="data_casamento" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Telefone</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-phone fa" aria-hidden="true"></i></span>
                            <input type="text" name="telefone" value="" placeholder="Telefone" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Batizado?</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <div class="form-control">
                                <input type="radio" name="batizado" value="sim"  />Sim
                                <input type="radio" name="batizado" value="nao"   />Não
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Sexo?</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <div class="form-control">
                                <input type="radio" name="sexo" value="masculino"  />Masculino
                                <input type="radio" name="sexo" value="feminino"   />Feminino
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Observação:</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-comment fa" aria-hidden="true"></i></span>
                            <textarea type="text" name="observacao"  placeholder="Dados complementares" class="form-control"></textarea>
                        </div>
                    </div>
                </div>
                <input type="hidden" name="_token" value="{{ csrf_token() }}">


                <div class="form-group ">
                    <input type="submit" name="name" class="btn btn-primary btn-lg btn-block login-button" value="Salvar">

                </div>

            </form>
        </div>
    </div>
</div>
@endsection