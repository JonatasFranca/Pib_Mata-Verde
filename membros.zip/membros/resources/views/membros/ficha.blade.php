


            <!doctype html>
            <html>
            <head>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
                <title>Ficha de Matricula</title>
                <style type="text/css">

                    /* Generic form fields */

                    fieldset.elist, input[type="text"], textarea, select, option, fieldset.elist ul, fieldset.elist > legend, fieldset.elist input[type="text"], fieldset.elist > legend:after {
                        -webkit-box-sizing: border-box;
                        -moz-box-sizing: border-box;
                        box-sizing: border-box;
                    }


                    fieldset {
                        border: 2px #af3333 solid;
                        border-radius: 10px;
                    }

                    /* Editable [pseudo]select (i.e. fieldsets with [class=elist]) */
                    p {
                        font-family: "Florence","cursive";
                    }



                </style>

            </head>
            <body>


            <fieldset>
                <figure ><center>
                <img src='css/imagem/pib- Mata Verde.jpg'><br><br><br><br>
                    </center>
                </figure>



                <h2 align="center">{{ $membros->nome }}</h2>


            </fieldset>

                <fieldset>
                    <h3>Dados Cadastrados</h3>
                        <p><b>Endereço:</b>
                            {{ $membros->rua }} - {{ $membros->bairro }}

                        </p>
                        <p><b>Estado Civil:</b>
                            {{ $membros->estado_civil }}
                        </p>

                        <p><b>Data Nascimento:</b>
                            {{date('d/m/Y', strtotime( $membros->data_nascimento ))}}
                        </p>
                        <p><b>Data Casamento:</b>
                            {{date('d/m/Y', strtotime( $membros->data_casamento ))}}
                        </p>

                        <p><b>Batizado:</b>
                        {{ $membros->batizado }}
                         </p>
                        <p><b>Sexo:</b>
                            {{ $membros->sexo }}
                        </p>
                    <p><b>Observações:</b>
                        {{ $membros->observacao}}
                    </p>
                </fieldset>



            </body>
            </html>