@extends('app')


@section('content')







    <div class="container">
        <div class="row main">
            <div class="main-login main-center">
                <div>
                    <figure align="right">
                        <img src="{{ asset('/css/imagem/pib- Mata Verde.jpg') }}" alt="pib"  height="140" width="200">
                    </figure>
                </div>

                <p>Homens - {{$totalm}} Mulheres - {{$totalf}}</p>
                <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
                <script type="text/javascript">
                    google.charts.load("current", {packages:["corechart"]});
                    google.charts.setOnLoadCallback(drawChart);
                    function drawChart() {

                        var data = google.visualization.arrayToDataTable([
                            ['produtos','mes'],

                            ['Masculino',{{$totalm}}],
                            ['Feminino',{{$totalf}}]

                        ]);

                        var options = {
                            title: 'Quantidade de membros por sexo',
                            is3D: true,
                        };

                        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
                        chart.draw(data, options);
                    }
                </script>


                <div id="piechart_3d" style="width: 500px; height: 200px;"></div>
                <p>Membros Batizados - {{$totalb}}, Membros não Batizados - {{$totaln}}</p>
                <script type="text/javascript">
                    google.charts.load("current", {packages:["corechart"]});
                    google.charts.setOnLoadCallback(drawChart1);
                    function drawChart1() {

                        var data = google.visualization.arrayToDataTable([
                            ['produtos1','mes1'],

                            ['Batizado',{{$totalb}}],
                            ['Não é batizado',{{$totaln}}]

                        ]);

                        var options = {
                            title: 'Quantidade de membros Batizados',
                            is3D: true,
                        };

                        var chart = new google.visualization.PieChart(document.getElementById('piechart_4d'));
                        chart.draw(data, options);
                    }
                </script>


                <div id="piechart_4d" style="width: 500px; height: 200px;"></div>

            </div>
        </div>
    </div>


@endsection