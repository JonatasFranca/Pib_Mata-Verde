@extends('app')


@section('content')
    <div class="container">
        <div class="row main">

            <div class="main-login main-center">
                <div>
                    <figure align="right">
                        <img src="{{ asset('/css/imagem/pib- Mata Verde.jpg') }}" alt="pib"  height="140" width="200">
                    </figure>
                </div>

                <h2>Detalhes</h2>
                <h3 class="form-group">{{ $detailpage->nome }}</h3>
                <div class="form-group">
                    <p><b>Endereço:</b>
                        {{ $detailpage->rua }} - {{ $detailpage->bairro }}

                    </p>
                </div>
                <div class="form-group">
                    <p><b>Estado Civil:</b>
                        {{ $detailpage->estado_civil }}
                    </p>
                </div>
                <div class="form-group">
                    <p><b>Data Nascimento:</b>
                        {{date('d/m/Y', strtotime ($detailpage->data_nascimento)) }}
                    </p>
                </div>
                @if( $detailpage->data_casamento != null)
                    <p><b>Data Casamento:</b>
                        {{date('d/m/Y', strtotime( $detailpage->data_casamento)) }}
                    </p>
                @endif

                <div class="form-group">
                    <p><b>Batizado:</b>
                        {{ $detailpage->batizado }}
                    </p>
                </div>
                <div class="form-group">
                    <p><b>Sexo:</b>
                        {{ $detailpage->sexo }}
                    </p>
                </div>
                <div class="form-group">
                    <p><b>Observações:</b>
                        {{ $detailpage->observacao }}
                    </p>
                </div>
                <div class="form-group">
                    <a href="{{ route('membros') }}" class="btn-sm btn-primary">Voltar</a>
                    <a href="{{route('membros.edit',['id'=>$detailpage->id])}}" class="btn-sm btn-default" >Editar</a>
                    <a href="{{route('membros.destroy',['id'=>$detailpage->id])}}" class="btn-sm btn-danger">Apagar</a>
                </div>
            </div>
        </div>
    </div>


@endsection