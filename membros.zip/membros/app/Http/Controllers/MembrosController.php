<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Membros;
use PDF;
use DB;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;

class MembrosController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth',['except' =>'show']);
    }

    public function index()
    {
        $membros = Membros::all();
        $total = DB::table('membros')->count();
        return view('membros.index',['todosmembros' =>$membros,'total'=>$total]);

    }
    public function create()
    {
        return view ('membros.create');
    }
    public function store(Request $request)
    {
        $input = $request->all();
        Membros::create($input);
        return redirect('membros')->with('message','Membro cadastrado com sucesso!');
    }
    public function show($id)
    {
        $membros = Membros::find($id);
        if(!$membros){
            abort(404);
        }
        return view('membros.details')->with('detailpage',$membros);

    }
    public function pdf($id)
    {
        $membros = Membros::find($id);
        $pdf = PDF::loadView('membros.ficha',compact('membros'));
        return $pdf->download('ficha_cadastral.pdf');

        //$membros = Membros::find($id);
        //if(!$membros){
          //  abort(404);
        //}
        //return view('membros.ficha')->with('membros',$membros);



    }
    public function edit($id)
    {
        $membros = Membros::find($id);
        if(!$membros){
            abort(404);
        }
        return view ('membros.edit')->with('detailpage',$membros);
    }
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'nome'=> 'required',
            'data_nascimento' => 'required',
        ]);
        $membros = Membros::find($id)->update($request->all());


        return redirect('membros')->with('message','Membro editado com sucesso!');

    }
    public function destroy($id)
    {
        $membros = Membros::find($id);
        $membros->delete();
        return redirect('membros')->with('message','Membro excluído!');
    }
    public function gerargrafico(){

        $membros = Membros::all();
        $totalf = DB::table('membros')->where('sexo', '=',"feminino")->count();
        $totalm = DB::table('membros')->where('sexo', '=',"masculino")->count();
        $totalb =  DB::table('membros')->where('batizado', '=',"sim")->count();
        $totaln =  DB::table('membros')->where('batizado', '=',"nao")->count();
        return view('membros.grafico', compact('membros','totalf','totalm','totalb','totaln'));

    }
}
