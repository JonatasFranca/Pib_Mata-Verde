<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Membros extends Model

{
    protected $fillable = ['nome','rua','bairro','estado_civil','data_nascimento','data_casamento','telefone','batizado','sexo','observacao','update_at','created_at'];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany = possui muitos
     * Um Evento possui muitas Matriculas
     */



}

