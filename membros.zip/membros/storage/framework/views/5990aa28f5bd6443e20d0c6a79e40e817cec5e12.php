<?php $__env->startSection('content'); ?>







    <div class="container">
        <div class="row main">
            <div class="main-login main-center">
                <div>
                    <figure align="right">
                        <img src="<?php echo e(asset('/css/imagem/pib- Mata Verde.jpg')); ?>" alt="pib"  height="140" width="200">
                    </figure>
                </div>
                <?php echo e(Session::get('message')); ?>


                    <a href="<?php echo e(route('membros.create')); ?>" class="btn-sm btn-primary" ><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Novo Membro</a>

                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>Membros</th>

                            <th>Total de Membros = <?php echo e($total); ?>  <a href="<?php echo e(route('membros.grafico')); ?>" ><span class="glyphicon glyphicon-stats" aria-hidden="true"></span></a></th>
                        </tr>
                        </thead>
                        <tbody>


                        <?php $__currentLoopData = $todosmembros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membros): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><a href="<?php echo e(route('membros.show',['id'=>$membros->id])); ?>" ><?php echo e($membros->nome); ?></a></td>


                                    <td>
                                        <a href="membros/<?php echo e($membros->id); ?>/edit" class="btn-sm btn-default" >Editar</a>
                                        <a href="<?php echo e(route('membros.pdf',['id'=>$membros->id])); ?>" class="btn-sm btn-success">Imprimir Ficha</a>



                                    </td>
                                </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>