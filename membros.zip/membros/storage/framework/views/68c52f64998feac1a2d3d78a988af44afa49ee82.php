<?php $__env->startSection('content'); ?>




<div class="container">
    <div class="row main">
        <div class="main-login main-center">
            <div>
                <figure align="right">
                    <img src="<?php echo e(asset('/css/imagem/pib- Mata Verde.jpg')); ?>" alt="pib"  height="140" width="200">
                </figure>
            </div>
            <h3>Auterar Cadastro</h3>
            <form class="" method="post" action="update">

                <div class="form-group">
                    <label for="name" class="cols-sm-2 control-label">Nome</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                            <input type="text" name="nome" value="<?php echo e($detailpage->nome); ?>" placeholder="Nome" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="email" class="cols-sm-2 control-label">Endereço</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home fa" aria-hidden="true"></i></span>
                            <input type="text" name="rua" value="<?php echo e($detailpage->rua); ?>" placeholder="Rua"class="form-control">
                        </div>
                    </div>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home fa" aria-hidden="true"></i></span>
                            <input type="text" name="bairro" value="<?php echo e($detailpage->bairro); ?>" placeholder="Bairro" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Estado Civil</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-heart fa" aria-hidden="true"></i></span>

                            <select  class="form-control" name="estado_civil" size="<?php echo e($detailpage->estado_civil); ?>">
                                <?php
                                $n = "solteiro";
                                $m = "casado";
                                $o = "divorciado";
                                ?>

                                 <?php if($detailpage->estado_civil == $n): ?>
                                 echo <option value="solteiro" selected>Solteiro</option>
                                        <option value="casado" > Casado</option>
                                        <option value="divorciado">Divorciado</option>;
                                    <?php elseif($detailpage->estado_civil == $m): ?>
                                        <option value="solteiro" >Solteiro</option>
                                        <option value="casado" selected> Casado</option>
                                        <option value="divorciado">Divorciado</option>;

                                    <?php else: ?>
                                        <option value="solteiro" selected>Solteiro</option>
                                        <option value="casado" > Casado</option>
                                        <option value="divorciado" selected >Divorciado</option>;

                                <?php endif; ?>
                            </select>
                        </div>
                    </div>

                </div>

                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Data Nascimento</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-calendar fa" aria-hidden="true"></i></span>
                            <input type="date" name="data_nascimento" value="<?php echo e($detailpage->data_nascimento); ?>" placeholder="data_nascimento" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Data Casamento</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-calendar fa" aria-hidden="true"></i></span>
                            <input type="date" name="data_casamento" value="<?php echo e($detailpage->data_casamento); ?>" placeholder="data_casamento" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Telefone</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-phone fa" aria-hidden="true"></i></span>
                            <input type="text" name="telefone" value="<?php echo e($detailpage->telefone); ?>" placeholder="Telefone" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Batizado?</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
                            <input type="text" name="batizado" value="<?php echo e($detailpage->batizado); ?>" placeholder="Sim ou Não" class="form-control">
                        </div>
                    </div>


                </div>
                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Sexo?</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
                            <input type="text" name="sexo" value="<?php echo e($detailpage->sexo); ?>"  class="form-control">
                        </div>
                    </div>


                </div>
                <div class="form-group">
                    <label for="username" class="cols-sm-2 control-label">Observação:</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-comment fa" aria-hidden="true"></i></span>
                            <input type="text" name="observacao"  value="<?php echo e($detailpage->observacao); ?>" class="form-control">
                        </div>
                    </div>
                </div>

                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">


                <div class="form-group ">
                    <input type="hidden" name="_method" value="put">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="submit" name="name" class="btn btn-primary btn-lg btn-block login-button" value="Salvar">

                </div>

            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>