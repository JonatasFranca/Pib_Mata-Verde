<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row main">

            <div class="main-login main-center">
                <div>
                    <figure align="right">
                        <img src="<?php echo e(asset('/css/imagem/pib- Mata Verde.jpg')); ?>" alt="pib"  height="140" width="200">
                    </figure>
                </div>

                <h2>Detalhes</h2>
                <h3 class="form-group"><?php echo e($detailpage->nome); ?></h3>
                <div class="form-group">
                    <p><b>Endereço:</b>
                        <?php echo e($detailpage->rua); ?> - <?php echo e($detailpage->bairro); ?>


                    </p>
                </div>
                <div class="form-group">
                    <p><b>Estado Civil:</b>
                        <?php echo e($detailpage->estado_civil); ?>

                    </p>
                </div>
                <div class="form-group">
                    <p><b>Data Nascimento:</b>
                        <?php echo e(date('d/m/Y', strtotime ($detailpage->data_nascimento))); ?>

                    </p>
                </div>
                <?php if( $detailpage->data_casamento != null): ?>
                    <p><b>Data Casamento:</b>
                        <?php echo e(date('d/m/Y', strtotime( $detailpage->data_casamento))); ?>

                    </p>
                <?php endif; ?>

                <div class="form-group">
                    <p><b>Batizado:</b>
                        <?php echo e($detailpage->batizado); ?>

                    </p>
                </div>
                <div class="form-group">
                    <p><b>Sexo:</b>
                        <?php echo e($detailpage->sexo); ?>

                    </p>
                </div>
                <div class="form-group">
                    <p><b>Observações:</b>
                        <?php echo e($detailpage->observacao); ?>

                    </p>
                </div>
                <div class="form-group">
                    <a href="<?php echo e(route('membros')); ?>" class="btn-sm btn-primary">Voltar</a>
                    <a href="<?php echo e(route('membros.edit',['id'=>$detailpage->id])); ?>" class="btn-sm btn-default" >Editar</a>
                    <a href="<?php echo e(route('membros.destroy',['id'=>$detailpage->id])); ?>" class="btn-sm btn-danger">Apagar</a>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>