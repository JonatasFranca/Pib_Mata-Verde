


            <!doctype html>
            <html>
            <head>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
                <title>Ficha de Matricula</title>
                <style type="text/css">

                    /* Generic form fields */

                    fieldset.elist, input[type="text"], textarea, select, option, fieldset.elist ul, fieldset.elist > legend, fieldset.elist input[type="text"], fieldset.elist > legend:after {
                        -webkit-box-sizing: border-box;
                        -moz-box-sizing: border-box;
                        box-sizing: border-box;
                    }


                    fieldset {
                        border: 2px #af3333 solid;
                        border-radius: 10px;
                    }

                    /* Editable [pseudo]select (i.e. fieldsets with [class=elist]) */
                    p {
                        font-family: "Florence","cursive";
                    }



                </style>

            </head>
            <body>


            <fieldset>
                <figure ><center>
                <img src='css/imagem/pib- Mata Verde.jpg'><br><br><br><br>
                    </center>
                </figure>



                <h2 align="center"><?php echo e($membros->nome); ?></h2>


            </fieldset>

                <fieldset>
                    <h3>Dados Cadastrados</h3>
                        <p><b>Endereço:</b>
                            <?php echo e($membros->rua); ?> - <?php echo e($membros->bairro); ?>


                        </p>
                        <p><b>Estado Civil:</b>
                            <?php echo e($membros->estado_civil); ?>

                        </p>

                        <p><b>Data Nascimento:</b>
                            <?php echo e(date('d/m/Y', strtotime( $membros->data_nascimento ))); ?>

                        </p>
                        <p><b>Data Casamento:</b>
                            <?php echo e(date('d/m/Y', strtotime( $membros->data_casamento ))); ?>

                        </p>

                        <p><b>Batizado:</b>
                        <?php echo e($membros->batizado); ?>

                         </p>
                        <p><b>Sexo:</b>
                            <?php echo e($membros->sexo); ?>

                        </p>
                    <p><b>Observações:</b>
                        <?php echo e($membros->observacao); ?>

                    </p>
                </fieldset>



            </body>
            </html>